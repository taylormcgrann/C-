﻿using System;
using static System.Console;
using System.IO;
/*
 * This program requests user hit and at bats for txt file names that are read in, accumulates the stats for each name and prints the totals out fo each name.
 */




//need to figure out the accumulation for at bats and hits, for each loop for that accumulation, 
namespace PlayBall01
{
    class Program
    {
        static void Main()
        //read the file at start
        {//array
            //string[] playerNumbers;
            //playerNumbers = new string[12];
            int[,] playerData = new int[2, 12];
            object[,] playerNumbers = new object[12, 3];
            double[,] playerStats = new double[3, 12];
            //accumulation array
            int[,] totals = new int[2, 12];
            //string anotherPlayer = "No";

            PlayerInit(playerNumbers);

            // playerNumbers = new int[12];


            //user option menu
            //while (anotherPlayer == "No")
            //{
                WriteLine("");
                WriteLine("");
                Console.WriteLine("Enter option 1 or 2. \n" +
                    "1: Enter player. \n" +
                    "2: Display Players.\n" +
                    "3: Exit.");
                int userOption = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("You chose option: " + userOption);

                if (userOption == 1)
                {
                    // ReadArray();
                    //InputData();
                    DisplayOne(playerNumbers);
                }
                else if (userOption == 2)
                {
                    //ReadArray();
                    DisplayData(playerNumbers);
                }
                else if (userOption == 3)
                {
                    System.Environment.Exit(0);
                }
                else
                {
                    WriteLine("Error, Must enter 1 or 2.");
                    WriteLine("");
                    Main();
                }
            }


       // }

        static void DisplayOne(object[,] playerNumbers)
        {
            char userInput = ' ';

            while (userInput != 'N')
            {
                int players = InputData();
                int atbats = EnterBats();
                int userHits = EnterHits();
               //accumulates the stats
                playerNumbers[players - 1, 1] = atbats + (int)playerNumbers[players - 1, 1];
                
                playerNumbers[players - 1, 2] = userHits + (int)playerNumbers[players - 1, 2];
                //display the out put
                DisplayData(playerNumbers);

            }

        }

        //array
        public static void PlayerInit(object[,] playerNumbers)
        {
            FileTime(playerNumbers);

            for (int i = 0; i < 12; i++)
            {
                playerNumbers[i, 1] = 0;
                playerNumbers[i, 2] = 0;
            }
        }
        public static void FileTime(object[,] playerNames)
        {


            const string FILENAME = "playerNames.txt";
            try
            {
                StreamReader reader = new StreamReader(FILENAME);
                string lines;
                int num = 0;

                //need to loop till the line reader has read every line in file //refer to 9/15 discussion kevin showed with hard coded array
                while ((lines = reader.ReadLine()) != null)
                {
                    playerNames[num, 0] = lines;
                    num++;
                }
                reader.Close();
            }
            catch (Exception)
            {
                WriteLine("File not found, press enter.");
                ReadLine();
                //need to either close program here or allow user to look at display
            }
        }

        public static int InputData()
        {
            int number = 0;
            bool ok = false;
            //var lines = File.ReadAllLines("playerNames.txt");

            while (!ok)
            {
                try
                {
                    WriteLine("Enter player number: ");
                    number = int.Parse(ReadLine());
                    //validation for player number
                    if (number > 0 && number <= 12)
                    {
                        ok = true;

                    }
                    else
                    {
                        WriteLine("Number must be 1-12");
                        ReadLine();
                    }

                }
                catch (Exception)
                {
                    WriteLine("Must enter a valid integer. Press enter");
                    Console.ReadLine();
                }
            }
            return number;

        }



        public static int EnterBats()
        {
            int atBats = 0;
            bool isNum = false;
            //prompt user to enter number of at bats
            //int inBats = 0;
            //need to loop until num is entered->>
            while (!isNum)
            {
                try
                {
                    WriteLine("Please enter at bats for player: ");
                    atBats = int.Parse(ReadLine());

                    //need to validate the at bats integer/ not a negative num
                    if (atBats >= 0)
                    {
                        isNum = true;

                    }
                    else
                    {
                        WriteLine("Number must be a positive integer. Press enter to enter a new number.");
                        ReadLine();
                    }
                }
                //check if a char is entered, if so loop back
                catch (Exception)
                {
                    WriteLine("Must be a number, no characters.");
                    ReadLine();
                }
            }
            return atBats;

        }

        static int EnterHits()
        {
            //string hits;
            //prompt user for number of hits
            int inHits = 0;
            bool okHit = false;

            
            while (!okHit)
            {
                try
                {
                    Console.WriteLine("Enter number of hits: ");
                    inHits = int.Parse(ReadLine());
                    //need to loop and validate for 0 division?
                    if (inHits >= 0)
                    {
                        okHit = true;
                    }//next need to make sure and validate for negative num, loop if not valid
                    else
                    {
                        WriteLine("Number needs to be positive integer. Hit enter to re-enter.");
                        ReadLine();
                    }

                }
                catch (Exception)
                {
                    WriteLine("Must be a number, no characters. Press enter to re-enter.");
                }
               
            }
            return inHits;
        }





        public static double CalcData(object[,] playerNumbers, int num)
        {
            //   WriteLine("Enter the number of bats: ");
            // playerNumbers[atBats, 1] = ReadLine();
            //need to store in the array, just make one array with the names as well-->> [,]
            double avg;
            int atBat = (int)playerNumbers[num, 1];
            int outHit = (int)playerNumbers[num, 2];
            //need to also avoid hitting 0 when dividing, if hit re enter?
            if (atBat > 0)
            {
                //cast avg to double to properly divide
                avg = (double)outHit / atBat;
            }
            else
            {
                avg = 0;
            }
            return avg;
        }
        /* // loop?
         for (int i = 0; i < playerNumbers.Length; i++)
         {
             double avg = 0;
             if (avg > 0)
             {
                 numHits++;
             }
         }
         double battingAverage = (double)numHits / playerNumbers.Length;
         WriteLine("Batting Avg: ");
         //playerNumbers[numHits, 3] = Console.ReadLine();
         return battingAverage;

 */


        private static void DisplayData(object[,] playerNumbers)
        {
            // int i = 0;
            int hitSum = 0;
            int batSum = 0;
            WriteLine("\n{0,-20}{1,-5}{2,20}{3,22}\n",
            "Name", "at Bats", "Hits", "Average");
            //need to loop refer back to discussion on 9/15 asked kevin about the input and display
            //need to print out all of the players, not just ones entered
            //12 for the names, (cant use the playerNumbers array messes up array)
            for (int i = 0; i < 12; i++)
            {
                // double battingAvg = CalcData(playerNumbers, i); loop was incorrect
                double battingAvg = CalcData(playerNumbers, i);
                int bats = (int)playerNumbers[i, 1];
                int hits = (int)playerNumbers[i, 2];


                //need to write the data in summary format, like reciept
                WriteLine("\n{0,-15}{1,-10}{2,6}{3,10} {4,5} {5,10} {6,7}\n", playerNumbers[i, 0], " ", bats.ToString("##,##0"), " ",
                    hits.ToString("#,##0"), " ", battingAvg.ToString("#.000"));
                
                //int hitSumTotal=playerNumbers.Aggregate((hitSumTotal)
                //accumulate totals
                /*foreach (int item in playerNumbers)
                {
                    hitSum += item;
                }
                Console.ReadLine();

                foreach (int item in playerNumbers)
                {
                    batSum += item;
                }
                Console.ReadLine(); */
            }
            //asks for another player kicks back to main if yes if no ki
            WriteLine("Do you want to enter another player? Yes or no(exit).");
            String anotherPlayer = Convert.ToString(Console.ReadLine());
            if (anotherPlayer == "yes")
            {
                Main();
            }
            else if (anotherPlayer == "Yes")
            {
                Main();
            }
            else
            {
                System.Environment.Exit(0);
            }


        }
        class Player
        {
            public string Name { get; set; }
            public int atBats { get; set; }
            public int hits { get; set; }
        }
    }
}


