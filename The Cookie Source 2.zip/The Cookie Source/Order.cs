﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
/// <summary>
/// instatiable class for cookie source that has constructors properties and methods.
/// 
/// </summary>
namespace The_Cookie_Source
{
    [Serializable]
    public class Order : IComparable
    {
        private int orderNum;
        private string name;
        private long phoneNum;
        private char cookieType;
        private int qty;
        //use current date
        private DateTime orderDate;
        //use date picker control, make sure user cant select date prior than order date
        private DateTime deliverDate;

        //make default and overloaded constructor to accept 

        public DateTime OrderDate
        {
            get { return orderDate; }
            set { orderDate = DateTime.Today; }
        }
        public DateTime DeliverDate
        {
            get { return deliverDate; }
            set { deliverDate = orderDate.AddDays(3); }
        }
        public int OrderNum
        {
            get
            { return orderNum; }
            set
            {
                if (value > 0)
                {
                     orderNum  += value;
                }
                else
                {
                    orderNum = 123;
                }
            }
        }

        public string Name
        {
            get { return name; }
            set
            {
                if (value.Trim().Length > 0)
                {
                    name = value.Trim();

                }
                else
                {
                    name = "Customer Name";
                }
            }
        }
        public long PhoneNum
        {
            get { return phoneNum; }
            set
            {
                if (value > 0)
                {
                    phoneNum = value;
                }
                else
                {
                    phoneNum = 123456789;
                }
            }
        }

        public char CookieType
        {
            get { return cookieType; }
            set
            {
                try
                {
                    if (char.IsWhiteSpace(value))
                    {
                        MessageBox.Show("No cookie type was selected", "Need value", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                    else if (char.ToUpper(value) == 'C' || char.ToUpper(value) == 'O' || char.ToUpper(value) == 'S')
                    {
                        cookieType = char.ToUpper(value);
                    }
                    else
                    {
                        MessageBox.Show("Wrong cookie type", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (FormatException e)
                {
                    MessageBox.Show(e.Message, "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        

        public int Qty
        {
            get { return qty; }
            set
            {
                try {
                    if (value > 0)
                    {
                        qty = value;
                    }
                    else
                    {
                        qty = 1;
                    }
                }catch(FormatException e)
                {
                    MessageBox.Show(e.Message, "Need Value", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                }
        }
       
        /// <summary>
        /// IComparable method with sort by delivery date
        /// </summary>
        /// <param name="o"></param>
        /// <returns></returns>
        /// 
        //Default Constructor
        public Order()
        {
            OrderNum = Interlocked.Increment(ref orderNum);
            Name = "Customer 1";
            PhoneNum = 6418951234;
            CookieType = 'C';
            Qty = 1;
            OrderDate = DateTime.Today;
            DeliverDate = DateTime.Today.AddDays(3);

        }
        //overloaded
        public Order(string name,long phoneNum, char cookieType,int qty,DateTime orderDate, DateTime deliverDate)
        {
            OrderNum = Interlocked.Increment(ref orderNum);
            Name = name;
            PhoneNum = phoneNum;
            CookieType = cookieType;
            Qty = qty;
            OrderDate = orderDate;
            DeliverDate = deliverDate;
        }
    int IComparable.CompareTo(Object o)
        {
            int returnVal;
            Order temp =(Order)o;
            if (this.deliverDate > temp.deliverDate)
                returnVal = 1;
            else
           if (this.deliverDate < temp.deliverDate)
                returnVal = -1;
            else
                returnVal = 0;
            return returnVal;
        }

    }

    class TryOrder
    {
         static void Main()
        {
            Order newOrder = new Order();
            newOrder.Name = "";
            newOrder.Qty = -1;


            try {
                newOrder.Name = "";
                newOrder.Qty = -1;
            }
            catch (InvalidNameException e)
            {
                WriteLine(e.Message);
                WriteLine(e.StackTrace);
            }
            catch(NegativeQtyException e)
            {
                WriteLine(e.Message);
                WriteLine(e.StackTrace);
            }
            }
    ///Custom exception

        class InvalidNameException : Exception
        {
            private static string msg = "Name can't be empty. ";
            public InvalidNameException() : base(msg)
            {

            }
        }
        class NegativeQtyException : Exception
        {
            private static string msg = "Qty cant be negative.";
            public NegativeQtyException() : base(msg)
            {

            }
        }
    } 
}

