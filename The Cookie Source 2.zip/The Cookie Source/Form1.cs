﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows.Forms;

namespace The_Cookie_Source
{
    public partial class Form1 : Form
    {
        public static List<Order> orderList = new List<Order>();

        public Form1()
        {
            InitializeComponent();

            //orderDate =DateTime.Today;
            //deliveryDate.Text="Cookies will be delivered on:" +orderDate.SelectionStart.AddDays(3).ToShortDateString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        { // may have to redo a new label for text also remove it from constructor
            Order o = new Order(txtName.Text,
                               Convert.ToInt64(txtPhone.Text),
                               Convert.ToChar(txtCookieType.Text),
                               Convert.ToInt32(txtQty.Text),
                               dateTimePicker1.Value,
                               dtpDeliverDate.Value);
                               
            
                               
            orderList.Add(o);
            txtName.Focus();
            txtName.SelectAll();
            //need to clear entry.
        }
        /// <summary>
        /// Exit button 
        /// also writes list to file
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnExit_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you wish write these books to the file",
                "Write To File", MessageBoxButtons.YesNo, MessageBoxIcon.Hand,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                try
                {
                    FileStream outFile = new FileStream("orderlist.ser",
                         FileMode.Create, FileAccess.Write);
                    BinaryFormatter bf = new BinaryFormatter();

                    foreach (var item in orderList)
                    {
                        bf.Serialize(outFile, item);
                    }
                    outFile.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error writing list to file " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("New items not written");
            }
            this.Close();
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            FormDisplay df = new FormDisplay();
            df.ShowDialog();
        }

        


        private void Form1_Load(object sender, EventArgs e)
        {
            dtpDeliverDate.MinDate = DateTime.Now;
            try
            {
                if (File.Exists("orderlist.ser"))
                {
                    using (Stream stream = File.Open("orderlist.ser",
                        FileMode.Open))
                    {
                        BinaryFormatter bin = new BinaryFormatter();
                        orderList = (List<Order>)bin.Deserialize(stream);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error Openining file, program ending" + ex.Message);
            }
        }
        private void dtpDeliverDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }



       

        private void txtCookieType_TextChanged(object sender, EventArgs e) { }

        
        /*{
   if (txtCookieType.Text == "C")
   {
       txtCookieType.Text = "Chocolate Chip";
   }else if (txtCookieType.Text == "O")
   {
       txtCookieType.Text = "OatMeal";
   }else if (txtCookieType.Text == "S")
   {
       txtCookieType.Text = "Sugar";
   }
   else
   {
       txtCookieType.Text = "N/A";
   }
}*/
    }
}


