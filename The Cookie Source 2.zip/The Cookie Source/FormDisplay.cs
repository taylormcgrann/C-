﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_Cookie_Source
{
    public partial class FormDisplay : Form
    {
        public FormDisplay()
        {
            InitializeComponent();
        }
        private void FormDisplay_Load(object sender, EventArgs e)
        {
           
            List<Order> orderList = new List<Order>(Form1.orderList);
            orderList.Sort();
            orderList.Reverse();
            
            foreach (var item in orderList)
            {
                displayLabel.Text +=
                    "Order Number: " +item.OrderNum +
                    "\n Customer Name: "+item.Name.PadRight(20) +
                    " Phone Number: "+item.PhoneNum.ToString().PadLeft(4) +
                    " Cookie Type: "+item.CookieType.ToString().PadLeft(6) +
                    " Quantity: "+ item.Qty.ToString().PadLeft(8) +
                    "\nOrder Date: "+item.OrderDate.ToString().PadRight(20) +
                    " Deliver Date: " +item.DeliverDate.ToString().PadLeft(25) +
                    Environment.NewLine;
            }
        
    }

        private void displayLabel_Click(object sender, EventArgs e)
        {

        }
            

        private void btnReturn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      /*  private void dateLabel_Click(object sender, EventArgs e)
        {
            List<Order> orderList = new List<Order>(Form1.orderList);
            orderList.Sort();
            orderList.Reverse();
            foreach (var item in orderList)
            {
                dateLabel.Text +=
                    item.OrderDate.ToString().PadRight(20) +
                    item.DeliverDate.ToString().PadLeft(4) +
                   
                    Environment.NewLine;
            }*/
        }
    }

