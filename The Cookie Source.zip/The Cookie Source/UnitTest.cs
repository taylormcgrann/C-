﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace The_Cookie_Source
{
    class UnitTest
    {

        static void Main()
        {
           // int x;

            Order order1 = new Order();
            //Tests Defaults
            order1.OrderNum = 0;
            order1.Name = "";
            order1.PhoneNum = -5;
            order1.Qty = -5;
            order1.CookieType = " ";

            Console.WriteLine("Order Num: " + order1.OrderNum + "\n" + " Customer Name: " + order1.Name + "\n" + "Phone Number :" + order1.PhoneNum
                + "\n" + "Qty: " + order1.Qty + " Cookie Type:" + order1.CookieType);
            Console.ReadLine();
        }
    }
}
